import random, pygame, time
pygame.init()

screen = pygame.display.set_mode([1500,800])

scrs = 100
scr1max = 0
scr2max = 0
scr3max = 0
scroll1 = 0
scroll2 = 0
scroll3 = 0

clicks = 0
timecoins = 0
boostdel = 1

clickss = 0
pressed_keys = []
lasttimemoney = time.time()
mauspos = (0,0)


class PressedKey:
    def __init__(self, name):
        self.name = name
        self.size = 20
        self.text = pygame.font.SysFont('arial',self.size).render(pygame.key.name(name),False,(0,0,0))
        self.x_pos = random.randint(int(screen.get_width()/6-20-schrift.get_width()/2),int(screen.get_width()/6+20+schrift.get_width()/2-self.text.get_width()))
        self.y_pos = 100
    def update(self):
        self.y_pos -= 1
        self.size = int((self.y_pos - 40)*0.27)
        if self.size >= 2:screen.blit(pygame.font.SysFont('arial',self.size).render(pygame.key.name(self.name),False,(0,0,0)),
                                      (self.x_pos,self.y_pos))
        else: pressed_keys.pop(0)
class Buyable:
    def __init__(self, name, preis, prod, mult=1.2):
        self.name = name
        self.price = preis
        self.prod = prod
        self.mult = mult
        self.bought = 0
        self.rect = pygame.Rect(0,0,0,0)
        self.lastproduce = time.time()
    def buy(self):
        global clicks
        if pygame.mouse.get_pressed(3)[0] and self.rect.colliderect(pygame.Rect(mauspos,(1,1)))\
                and clicks >= self.price:
            self.bought += 1
            clicks -= self.price
            self.price = int(self.price * self.mult)
            time.sleep(0.1)
    def show(self):
        global buyableCount, clicks
        font = pygame.font.SysFont('arial',20)
        if buyableCount * 100 + scroll1 * scrs >= 0:
            self.rect = pygame.Rect(screen.get_width()-1000, buyableCount*100+scroll1*scrs, 300, 100)
            if self.price <= clicks: pygame.draw.rect(screen, (0,255,0), self.rect)
            else: pygame.draw.rect(screen, (0,0,0), self.rect)
            pygame.draw.rect(screen, (255,0,0), pygame.Rect(screen.get_width() - 997, buyableCount*100+scroll1*scrs+3, 294, 94))
            screen.blit(font.render(self.name, False, (0,0,255)),(screen.get_width() - 990,buyableCount*100+scroll1*scrs+5))
            screen.blit(font.render(str(self.price)+' €', False, (0,0,0)),(screen.get_width() - 990,buyableCount*100+scroll1*scrs+25))
            screen.blit(font.render(str(self.prod)+' €  (ges.: '+ str(round(self.prod * self.bought,1))+' € )', False, (0,0,0)),(screen.get_width() - 990,buyableCount*100+scroll1*scrs+45))
            screen.blit(font.render('Gekauft:'+ str(self.bought), False, (0,0,0)),(screen.get_width() - 990,buyableCount*100+scroll1*scrs+75))

        buyableCount += 1
    def click(self):
        global clicks, clickss
        clickss += self.prod * self.bought
        if time.time() - self.lastproduce >= 0.1:
            clicks += self.prod*0.1*self.bought
            self.lastproduce = time.time()
    def doAll(self):
        self.buy()
        self.show()
        self.click()
class Upgrade:
    def __init__(self, name, preis, building, moreprod=1.1, mult=1.4):
        self.name = name
        self.price = preis
        self.building = building
        self.moreprod = moreprod
        self.mult = mult
        self.bought = 0
        self.rect = pygame.Rect(0,0,0,0)
    def buy(self):
        global clicks
        if pygame.mouse.get_pressed(3)[0] and self.rect.colliderect(pygame.Rect(mauspos,(1,1))) and clicks >= self.price:
            self.bought += 1
            self.building.prod = round(self.building.prod * self.moreprod,1)
            clicks -= self.price
            self.price = int(self.price * self.mult)
            time.sleep(0.1)
    def show(self):
        global upgradecount
        font = pygame.font.SysFont('arial',20)
        if upgradecount * 100 + scroll2 * scrs >= 0:
            self.rect = pygame.Rect(screen.get_width()-600, upgradecount*100+scroll2*scrs, 300, 100)
            if self.price <= clicks: pygame.draw.rect(screen, (0,255,0), self.rect)
            else: pygame.draw.rect(screen, (0,0,0), self.rect)
            pygame.draw.rect(screen, (255,0,0), pygame.Rect(screen.get_width() - 597, upgradecount*100+scroll2*scrs+3, 294, 94))
            screen.blit(font.render(self.name, True, (0,255,255)),(screen.get_width() - 590,upgradecount*100+scroll2*scrs+5))
            screen.blit(font.render(str(self.price)+' €', False, (0,0,0)),(screen.get_width() - 590,upgradecount*100+scroll2*scrs+25))
            screen.blit(font.render('Produktion von '+self.building.name+' * '+str(self.moreprod), False, (0,0,0)),(screen.get_width() - 590,upgradecount*100+scroll2*scrs+45))
            screen.blit(font.render('Gekauft:'+ str(self.bought), False, (0,0,0)),(screen.get_width() - 590,upgradecount*100+scroll2*scrs+75))

        upgradecount += 1
    def doAll(self):
        self.buy()
        self.show()
class Boost:
    def __init__(self, name, preis, building, moreprod:float=2):
        self.name = name
        self.price = preis
        self.building = building
        self.moreprod = moreprod
        self.bought = 0
        self.rect = pygame.Rect(0,0,0,0)
    def buy(self):
        global timecoins, boosts, boostdel
        if pygame.mouse.get_pressed(3)[0] and self.rect.colliderect(pygame.Rect(mauspos,(1,1))) and timecoins >= self.price:
            self.bought += 1
            try:self.building.prod = round(self.building.prod * self.moreprod,1)
            except:
                if self.building == boostdel: boostdel *= self.moreprod
            timecoins -= self.price
            boosts.pop(boosts.index(self))
            time.sleep(0.1)
    def show(self):
        global boostcount
        font = pygame.font.SysFont('arial',20)
        if boostcount*100+scroll3*scrs>=0:
            self.rect = pygame.Rect(screen.get_width()-300, boostcount*100+scroll3*scrs, 300, 100)
            if self.price <= timecoins: pygame.draw.rect(screen, (0,255,0), self.rect)
            else: pygame.draw.rect(screen, (0,0,0), self.rect)
            pygame.draw.rect(screen, (255,0,0), pygame.Rect(screen.get_width() - 297, boostcount*100+scroll3*scrs+3, 294, 94))
            screen.blit(font.render(self.name, True, (255,255,255)),(screen.get_width() - 290,boostcount*100+scroll3*scrs+5))
            screen.blit(font.render(str(self.price) + 'tm', False, (0,0,0)),(screen.get_width() - 290,boostcount*100+scroll3*scrs+25))
            try:screen.blit(font.render('Produktion von '+self.building.name+' * '+str(self.moreprod), False, (0,0,0)),(screen.get_width() - 290,boostcount*100+scroll3*scrs+45))
            except:screen.blit(font.render('Produktionsdauer von Zeitgeld * '+str(self.moreprod), False, (0,0,0)),(screen.get_width() - 290,boostcount*100+scroll3*scrs+45))
            screen.blit(font.render('Gekauft:'+ str(self.bought), False, (0,0,0)),(screen.get_width() - 290,boostcount*100+scroll3*scrs+75))

        boostcount += 1
    def doAll(self):
        self.buy()
        self.show()
class HiddenBoost:
    def __init__(self, unit, cond, name, preis, building, moreprod: float = 2):
        self.name = name
        self.price = preis
        self.building = building
        self.moreprod = moreprod
        self.bought = 0
        self.rect = pygame.Rect(0, 0, 0, 0)
        self.cond = cond
        self.unit = unit
    def check(self):
        if self.unit == 'clicks' and clicks >= self.cond:
            boosts.append(Boost(self.name, self.price, self.building, self.moreprod))
            hiddenboosts.pop(hiddenboosts.index(self))
        elif self.unit == 'timecoins' and timecoins >= self.cond:
            boosts.append(Boost(self.name, self.price, self.building, self.moreprod))
            hiddenboosts.pop(hiddenboosts.index(self))
        elif type(self.unit) == Buyable:
            if self.unit.bought >= self.cond and clicks >= self.cond:
                boosts.append(Boost(self.name, self.price, self.building, self.moreprod))
                hiddenboosts.pop(hiddenboosts.index(self))


buyables = [Buyable('Taste',100,1),
            Buyable('Tastatur',500,4),
            Buyable('Teilzeitarbeiter', 3000,15),
            Buyable('Vollzeitarbeiter', 20000, 60),
            Buyable('Sklave', 150000, 300),
            Buyable('Büro', 1000000, 1500),
            Buyable('Abteilung', 7000000, 7000),
            Buyable('Geschäft', 50000000, 30000),
            Buyable('Zwangsarbeitslager', 400000000, 125000)]
upgrades = [Upgrade('Tastenwechsel', 100, buyables[0]),
            Upgrade('Neue Tastatur', 500, buyables[1]),
            Upgrade('Lohnerhöhung', 3000, buyables[2]),
            Upgrade('Büroverschönerung', 20000, buyables[3]),
            Upgrade('Verpflegung', 150000, buyables[4]),
            Upgrade('Besseres Essen', 1000000, buyables[5]),
            Upgrade('Neuer Boss', 7000000, buyables[6]),
            Upgrade('Neuer Standort', 50000000, buyables[7]),
            Upgrade('Vermeintlicher Putschversuch', 400000000, buyables[8])]
boosts = [Boost('Motivation', 100, buyables[0]),
          Boost('Neue Hand', 200, buyables[1]),
          Boost('Überstunden', 300, buyables[2]),
          Boost('Nachtschicht', 500, buyables[3]),
          Boost('Zeitmaschine', 50, boostdel, 0.8),
          Boost('Sklaventreiber', 700, buyables[4]),
          Boost('Neue Kantine', 1000, buyables[5]),
          Boost('Bessere Mitarbeiter', 1500, buyables[6]),
          Boost('Staatliche Förderung', 2000, buyables[7]),
          Boost('Säuberungen im Senat', 2500, buyables[8])]
hiddenboosts = [HiddenBoost(buyables[0], 10, 'Klein aber fein', 100, buyables[0]),
                HiddenBoost(buyables[1], 10, 'Schnelle Klicks', 100, buyables[1]),
                HiddenBoost(buyables[2], 10, 'Bürovergrößerung', 150, buyables[2]),
                HiddenBoost(buyables[3], 10, 'Noch eine Bürovergrößerung', 150, buyables[3]),
                HiddenBoost(buyables[4], 10, 'Darf er das?!', 200, buyables[4]),
                HiddenBoost(buyables[5], 10, 'Industrialisierung', 250, buyables[5]),
                HiddenBoost(buyables[6], 10, 'Industrialisierung 2.0', 250, buyables[6]),
                HiddenBoost(buyables[7], 10, 'Industrialisierung 3.0 ??', 300, buyables[7]),
                HiddenBoost(buyables[8], 10, 'Ich Boss, du nix', 350, buyables[8]),
                HiddenBoost(buyables[0], 25, 'Kleiner aber feiner', 400, buyables[0]),
                HiddenBoost(buyables[1], 25, 'Noch schnellere Klicks', 400, buyables[1]),
                HiddenBoost(buyables[2], 25, 'Ultimative Bürovergrößerung', 450, buyables[2]),
                HiddenBoost(buyables[3], 25, 'Illegale Mittel', 450, buyables[3]),
                HiddenBoost(buyables[4], 25, 'Er darf das!!', 500, buyables[4]),
                HiddenBoost(buyables[5], 25, 'Industrialisierung', 550, buyables[5]),
                HiddenBoost(buyables[6], 25, 'Industrialisierung 2.1', 550, buyables[6]),
                HiddenBoost(buyables[7], 25, 'Industrialisierung 3.1 !!', 600, buyables[7]),
                HiddenBoost(buyables[8], 25, 'UNTERDRÜCKUNG!!', 650, buyables[8]),
                HiddenBoost('timecoins', 100, 'Atomuhr', 100, boostdel, 0.7),
                HiddenBoost('timecoins', 150, 'Wer hat an der Uhr gedreht?', 300, boostdel, 0.5)]

while True:
    mauspos = pygame.mouse.get_pos()
    upgradecount = 0
    buyableCount = 0
    boostcount = 0
    clickss = 0
    schrift = pygame.font.SysFont('arial',80).render(str(int(clicks)), False, (0,0,0))
    screen.fill((255,255,255))
    pygame.draw.rect(screen,(255,0,0),pygame.Rect(screen.get_width()/6-20-schrift.get_width()/2,110,schrift.get_width()+40,schrift.get_height()+20))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:quit()
        if event.type == pygame.KEYDOWN:
            clicks += 1
            pressed_keys.append(PressedKey(event.key))
        if event.type == pygame.MOUSEWHEEL:
            if mauspos[0] in range(500,799): scroll1 += event.y
            if mauspos[0] in range(900,1199): scroll2 += event.y
            if mauspos[0] in range(1200,1499): scroll3 += event.y
            if scroll1*scrs < scr1max: scroll1 = int(scr1max/scrs)
            if scroll2*scrs < scr2max: scroll2 = int(scr2max/scrs)
            if scroll3*scrs < scr3max: scroll3 = int(scr3max/scrs)
            if scroll1 > 0: scroll1 = 0
            if scroll2 > 0: scroll2 = 0
            if scroll3 > 0: scroll3 = 0

    if time.time() - lasttimemoney >= boostdel:
        timecoins += 1
        lasttimemoney = time.time()
    for i in pressed_keys:i.update()
    for i in buyables:i.doAll()
    for i in upgrades:i.doAll()
    for i in hiddenboosts: i.check()
    boosts.sort(key=lambda x: x.price)
    for i in boosts:i.doAll()
    scr1max = screen.get_height()-len(buyables)*100
    scr2max = screen.get_height()-len(upgrades)*100
    scr3max = screen.get_height()-len(boosts)*100
    screen.blit(schrift,(screen.get_width()/6-schrift.get_width()/2,120))
    clicksstext = pygame.font.SysFont('arial',20).render('Clicks pro Sekunde: '+str(round(clickss,1)), False, (0,0,0))
    screen.blit(clicksstext, (screen.get_width() / 6 - clicksstext.get_width() / 2, 220))
    timetext = pygame.font.SysFont('arial',20).render(str(timecoins), False, (0,0,0))
    screen.blit(timetext, (screen.get_width() / 6 - timetext.get_width() / 2, 520))
    pygame.display.flip()
    pygame.time.Clock().tick(100)
